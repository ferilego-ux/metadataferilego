import React, { useState } from "react";

export default function App() {
  const [apiKey, setApiKey] = useState("");
  const [prompt, setPrompt] = useState(""); // describe video
  const [loading, setLoading] = useState(false);
  const [entries, setEntries] = useState([]);

  async function generateMetadata() {
    if (!apiKey) return alert("Enter your OpenAI API key first.");
    if (!prompt) return alert("Describe your video first.");

    setLoading(true);

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: "You are an expert in Adobe Stock SEO metadata creation. Generate a strong title (under 70 chars), a 2-sentence description, and exactly 49 optimized keywords (comma-separated, long-tail, and buyer intent based). Also suggest the most appropriate Adobe category.",
            },
            {
              role: "user",
              content: `Analyze this video: ${prompt}`,
            },
          ],
        }),
      });

      const data = await response.json();
      const text = data.choices?.[0]?.message?.content || "No result";

      // Try to parse output into title/desc/keywords/category via simple markers
      // If parsing fails, store raw text in description.
      const parsed = parseMetadata(text);
      const entry = {
        id: Date.now(),
        filename: parsed.filename || (parsed.title || 'metadata').toLowerCase().replace(/[^a-z0-9]+/g,'-'),
        title: parsed.title || '',
        description: parsed.description || text,
        keywords: parsed.keywords || [],
        category: parsed.category || '',
        raw: text
      };
      setEntries(prev => [entry, ...prev]);
    } catch (err) {
      console.error(err);
      alert('Error generating metadata. Check API key & network.');
    } finally {
      setLoading(false);
      setTimeout(()=> {
        const node = document.querySelector('.result');
        if(node) node.scrollIntoView({behavior:'smooth', block:'center'});
      }, 80);
    }
  }

  function parseMetadata(text) {
    // naive parsing: look for lines starting with Title:, Description:, Keywords:, Category:
    const res = { title:'', description:'', keywords:[], category:'', filename:'' };
    const titleMatch = text.match(/title\s*[:\-]\s*(.*)/i);
    const descMatch = text.match(/description\s*[:\-]\s*([\s\S]*?)(?=keywords\s*[:\-]|category\s*[:\-]|$)/i);
    const keyMatch = text.match(/keywords\s*[:\-]\s*([\s\S]*?)(?=category\s*[:\-]|$)/i);
    const catMatch = text.match(/category\s*[:\-]\s*(.*)/i);

    if(titleMatch) res.title = titleMatch[1].trim();
    if(descMatch) res.description = descMatch[1].trim();
    if(keyMatch) {
      const keys = keyMatch[1].split(/[,\n]/).map(k=>k.trim()).filter(Boolean);
      res.keywords = keys.slice(0,49);
    }
    if(catMatch) res.category = catMatch[1].trim();
    return res;
  }

  function exportAllCSV() {
    const header = ['filename','title','description','keywords','category'];
    const rows = entries.map(e=> [e.filename, e.title, e.description, e.keywords.join(', '), e.category]);
    const csv = [header.join(',')].concat(rows.map(r=> r.map(c=> '"'+String(c).replace(/"/g,'""')+'"').join(','))).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'metadata_export.csv'; a.click(); URL.revokeObjectURL(url);
  }

  function exportSingleCSV(entry){
    const header = ["filename","title","description","keywords","category"];
    const row = [entry.filename || "", entry.title, entry.description, entry.keywords.join(", "), entry.category];
    const csv = [header.join(",") , row.map(c => '"'+String(c).replace(/"/g,'""')+'"').join(",")].join("\n");
    const blob = new Blob([csv],{type:"text/csv;charset=utf-8;"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = (entry.filename || "metadata") + ".csv"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container">
      <h1 className="h1">metadataAiferilego</h1>
      <p className="sub">Generate perfect SEO metadata (exactly 49 keywords) for Adobe Stock videos — dark premium UI.</p>

      <div style={{display:'grid', gap:10}}>
        <input className="input" type="password" placeholder="OpenAI API Key (sk-...)" value={apiKey} onChange={(e)=>setApiKey(e.target.value)} />
        <textarea className="input" placeholder="Describe your video: e.g. cinematic red graph dropping sharply, dark studio background, 4K" value={prompt} onChange={(e)=>setPrompt(e.target.value)} style={{height:90}} />
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <button className="btn" onClick={generateMetadata} disabled={loading}>{loading? 'Generating...':'Generate Metadata'}</button>
          <button className="csv" onClick={exportAllCSV} disabled={entries.length===0}>Export All CSV</button>
        </div>
      </div>

      <div style={{marginTop:18}}>
        {entries.length===0 && <div className="card">No results yet. Generate to see output here.</div>}
        {entries.map(e=> (
          <div key={e.id} className="card result fade-slide" style={{marginTop:12}}>
            <div className="meta">
              <div style={{display:'flex',alignItems:'center'}}><div className="loader"/></div>
              <div style={{flex:1}}>
                <div style={{fontSize:14, fontWeight:600}}>{e.title}</div>
                <div style={{color:'#9aa3af', fontSize:13, marginTop:4}}>{e.category}</div>
              </div>
              <button className="csv" onClick={()=>exportSingleCSV(e)}>Export CSV</button>
            </div>
            <div style={{marginTop:8}}>
              <div style={{fontSize:13, color:'#cfd9e6', marginBottom:8}}>{e.description}</div>
              <div className="chips">{e.keywords.map((k,i)=>(<div className="chip" key={i} title={k}>{k}</div>))}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
